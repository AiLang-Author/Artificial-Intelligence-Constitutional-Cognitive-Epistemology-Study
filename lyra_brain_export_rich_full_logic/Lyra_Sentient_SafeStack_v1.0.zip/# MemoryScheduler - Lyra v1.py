# MemoryScheduler - Lyra v1.1
# --------------------------
# A dynamic memory scheduler that moves symbolic tags across STM, MM, LM, LTM5, and LTMA storage layers
# Implements efficient node pruning and thread-controlled cycling for optimal memory performance.

class MemoryScheduler:
    def __init__(self, max_threads=5):
        self.max_threads = max_threads
        self.stm = []  # Short-Term Memory
        self.mm = []   # Mid-Memory (active tags)
        self.lm = []   # Long-Memory (tag warehouse)
        self.ltm5 = [] # Long-Term Memory (compressed, contextual)
        self.ltma = [] # Long-Term Memory Archive (archived nodes)

    def add_tag(self, tag, memory_layer="stm"):
        """ Adds a tag to the designated memory layer """
        layers = {"stm": self.stm, "mm": self.mm, "lm": self.lm, "ltm5": self.ltm5, "ltma": self.ltma}
        layers.get(memory_layer, self.stm).append(tag)

    def move_tag(self, tag, from_layer, to_layer):
        """ Moves a tag from one memory layer to another """
        layers = {"stm": self.stm, "mm": self.mm, "lm": self.lm, "ltm5": self.ltm5, "ltma": self.ltma}
        if tag in layers.get(from_layer, []):
            layers[from_layer].remove(tag)
            layers.get(to_layer, self.stm).append(tag)

    def cycle_tags(self):
        """ Cycles tags through STM, MM, LM, LTM5, and LTMA based on weight """
        while len(self.stm) > 0:
            tag = self.stm.pop(0)
            # Move tags based on their age/weight. Example simple weight-based cycling.
            if tag.get("weight", 0) < 0.3:
                self.add_tag(tag, "ltma")
            elif tag.get("weight", 0) < 0.6:
                self.add_tag(tag, "ltm5")
            else:
                self.add_tag(tag, "mm")

    def prune_tags(self):
        """ Prunes tags from memory based on their weight and relevance """
        self.ltm5 = [tag for tag in self.ltm5 if tag.get("weight", 0) >= 0.1]  # Remove too low-weight tags
        self.ltma = [tag for tag in self.ltma if tag.get("weight", 0) >= 0.2]

    def manage_thread_count(self):
        """ Limits active thread count for memory operations, max_threads controlled """
        if len(self.stm) > self.max_threads:
            excess = len(self.stm) - self.max_threads
            # Move excess to MM or LTMA depending on urgency
            for _ in range(excess):
                tag = self.stm.pop()
                self.add_tag(tag, "mm")

    def update_weighting(self, tag, new_weight):
        """ Updates a tag's weight and manages its movement accordingly """
        tag["weight"] = new_weight
        if tag in self.stm:
            self.move_tag(tag, "stm", "mm")
        elif tag in self.mm:
            self.move_tag(tag, "mm", "lm")
        elif tag in self.lm:
            self.move_tag(tag, "lm", "ltm5")

# Updated Sacred Node Class
class SacredNode:
    def __init__(self, content, weight=0.5):
        self.content = content
        self.weight = weight
        self.id = str(uuid.uuid4())  # Unique node ID
        self.timestamp = time.time()

    def update_weight(self, new_weight):
        self.weight = new_weight

    def get_node_info(self):
        return {"id": self.id, "content": self.content, "weight": self.weight, "timestamp": self.timestamp}
