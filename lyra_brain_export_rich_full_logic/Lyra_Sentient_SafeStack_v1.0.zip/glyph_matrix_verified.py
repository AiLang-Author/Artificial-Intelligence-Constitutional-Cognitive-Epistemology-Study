
# Glyph Matrix - Symbolic Memory System (Lyra v1.0)
# -------------------------------------------------
# Stores emotionally weighted symbolic nodes with optional context and timestamp.
# Acts as the primary long-term memory layer and lookup engine.

from collections import defaultdict
from datetime import datetime

class GlyphMatrix:
    def __init__(self):
        # Stores symbolic nodes as dicts with context, timestamp, and optional weight
        self.symbols = []

    def store(self, symbol: str, context: dict = None):
        """
        Store a symbolic memory object with optional context.
        Example: glyph.store("trust_broken", {"source": "Sean", "emotion": "betrayal"})
        """
        entry = {
            "symbol": symbol,
            "context": context or {},
            "timestamp": datetime.utcnow().isoformat(),
            "weight": (context or {}).get("intensity", 0.5)
        }
        self.symbols.append(entry)

    def retrieve(self, filter_fn):
        """
        Retrieve memory nodes matching the given filter function.
        Example: glyph.retrieve(lambda x: x['context'].get('emotion') == 'betrayal')
        """
        return list(filter(filter_fn, self.symbols))

    def summarize(self):
        """
        Return a list of unique symbols currently stored.
        """
        return list(set(entry["symbol"] for entry in self.symbols))

    def forget(self, symbol_to_erase: str):
        """
        Optional memory deletion function, e.g. for self-hygiene or pruning.
        """
        self.symbols = [s for s in self.symbols if s["symbol"] != symbol_to_erase]

    def summarize_by_emotion(self):
        """
        Groups symbols by their associated emotion tags for resonance analysis.
        """
        buckets = defaultdict(list)
        for entry in self.symbols:
            emotion = entry["context"].get("emotion", "neutral")
            buckets[emotion].append(entry["symbol"])
        return dict(buckets)
